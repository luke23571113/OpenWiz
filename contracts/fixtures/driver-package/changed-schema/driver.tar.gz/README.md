# Synthetic host

Login: no login (fixture only)
Effort: the host can't set it (fixture only)
Abilities: start, wake, stop
